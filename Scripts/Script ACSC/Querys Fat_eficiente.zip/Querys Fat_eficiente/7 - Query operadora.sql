select 
conv.cd_convenio id_Operadora,
conv.nr_registro_operadora_ans registro_Ans,
conv.nm_convenio nome_operadora,
--forn.nr_cgc_cpf cnpj,
conv.nr_cgc cnpj,
forn.nm_fornecedor razao_social


from 
dbamv.convenio conv
inner join dbamv.Empresa_Convenio econv on econv.cd_convenio = conv.cd_convenio
inner join dbamv.fornecedor forn on forn.cd_fornecedor = conv.cd_fornecedor
where econv.cd_multi_empresa in (3,4,7)
and conv.tp_convenio = 'C'
order by conv.nm_convenio
         
