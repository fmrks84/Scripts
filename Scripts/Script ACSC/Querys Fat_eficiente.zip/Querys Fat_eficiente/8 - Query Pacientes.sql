select 
pct.cd_paciente id_paciente,
pct.nm_paciente nome_paciente,
pct.nr_cns numero_cns,
pct.dt_nascimento data_nascimento,
decode(pct.tp_sexo,'M','MASCULINO','F','FEMININO')SEXO,
pct.dt_cadastro,
pct.nm_usuario responsavel_cadastro,
pct.dt_ultima_atualizacao data_atualizacao,
pct.nm_usuario_ultima_atualizacao responsavel_atualizacao
 
from 
dbamv.paciente pct
order by 2
--where atend.cd_atendimento = 2385933
