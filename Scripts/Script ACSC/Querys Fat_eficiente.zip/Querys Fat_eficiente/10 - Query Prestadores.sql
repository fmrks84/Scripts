select 
emp.cd_multi_empresa id_prestador,
emp.nr_cnes cnes,
emp.ds_multi_empresa nome,
emp.cd_cgc,
emp.ds_razao_social,
''data_Cadastro,
''responsavel_cadastro,
''data_atualizacao,
''responsavel_atualizacao
from 
dbamv.multi_empresas emp
where  emp.sn_ativo = 'S'
order by 1
