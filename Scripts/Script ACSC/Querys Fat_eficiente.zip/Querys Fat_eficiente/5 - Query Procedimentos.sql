select 

rf.cd_atendimento id,
rf.cd_reg_fat idconta,
tts.cd_tip_tuss codigo_tabela,
dbamv.fc_ovmd_tuss(rf.cd_multi_empresa,
                   irf.cd_pro_fat,
                    rf.cd_convenio,
                   'COD')CD_TUSS,
dbamv.fc_ovmd_tuss(rf.cd_multi_empresa,
                   irf.cd_pro_fat,
                    rf.cd_convenio,
                   'DESC')DS_TUSS,        
gf.ds_gru_fat Codigo_Despesa,
pf.ds_unidade Unidade_Medida,       
rf.dt_inicio,
rf.dt_final,
irf.qt_lancamento,
''reducao_Acrescimo , 
irf.vl_unitario vl_unitario,
irf.vl_total_conta valor_total,
'UNICA'VIA_ACESSO,
'CONVENCIONAL'TECNICA_UTILIZADA,
IRF.CD_PRESTADOR ID_PRESTADOR,
prest.nm_prestador nome_profissional,
case 
when irf.cd_ati_med IN (07,15)
then 'Clinico'
wheN irf.cd_ati_med IN (01)
then 'Cirurgi�o'
when irf.cd_ati_med IN (02,16)
then 'Primeiro Auxiliar' 
when irf.cd_ati_med IN (03,17)
then 'Segundo Auxiliar'
when irf.cd_ati_med IN (03,17)
then 'Segundo Auxiliar'
when irf.cd_ati_med IN (04)
then 'Terceiro Auxiliar'
when irf.cd_ati_med IN (09)
then 'Instrumentador'     
when irf.cd_ati_med IN (06)
then 'Anestesista' 
when irf.cd_ati_med IN (14)
then 'Intensivista' 
end Grau_Participacao
from 
dbamv.reg_Fat rf
inner join dbamv.itreg_fat irf on irf.cd_reg_fat = rf.cd_reg_fat
inner join dbamv.atendime atend on atend.cd_atendimento = rf.cd_atendimento
inner join dbamv.convenio conv on conv.cd_convenio = rf.cd_convenio
left join dbamv.tuss ts on ts.cd_pro_fat = irf.cd_pro_fat and ts.cd_multi_empresa = rf.cd_multi_empresa 
                                                          and ts.cd_convenio = rf.cd_convenio
inner join dbamv.gru_fat gf on gf.cd_gru_fat = irf.cd_gru_fat
inner join dbamv.pro_Fat pf on pf.cd_pro_fat = irf.cd_pro_fat
inner join dbamv.tip_tuss tts on tts.cd_tip_tuss = ts.cd_tip_tuss
left join dbamv.prestador prest on prest.cd_prestador = irf.cd_prestador
and ts.dt_fim_vigencia is null
where conv.tp_convenio = 'C'
--and rf.cd_atendimento = 2541525--,2385933,2541525--2588415,2541525
--and irf.sn_pertence_pacote = 'N'

UNION ALL

select 
iramb.Cd_Atendimento id,
ramb.cd_reg_amb idconta,
tts1.cd_tip_tuss codigo_tabela,
dbamv.fc_ovmd_tuss(ramb.cd_multi_empresa,
                   iramb.cd_pro_fat,
                    iramb.cd_convenio,
                   'COD')CD_TUSS,
dbamv.fc_ovmd_tuss(ramb.cd_multi_empresa,
                   iramb.cd_pro_fat,
                    iramb.cd_convenio,
                   'DESC')DS_TUSS,
gf1.ds_gru_fat codigo_despesa,
pf1.ds_unidade unidade_medida,
iramb.hr_lancamento dt_inicio,
iramb.hr_lancamento dt_final,
iramb.qt_lancamento,
''reducao_acrescimo,
iramb.vl_unitario,
iramb.vl_total_conta,
'UNICA'VIA_ACESSO,
'CONVENCIONAL'TECNICA_UTILIZADA,
iramb.CD_PRESTADOR ID_PRESTADOR,
prest1.nm_prestador nome_profissional,
case 
when iramb.cd_ati_med IN (07,15)
then 'Clinico'
wheN iramb.cd_ati_med IN (01)
then 'Cirurgi�o'
when iramb.cd_ati_med IN (02,16)
then 'Primeiro Auxiliar' 
when iramb.cd_ati_med IN (03,17)
then 'Segundo Auxiliar'
when iramb.cd_ati_med IN (03,17)
then 'Segundo Auxiliar'
when iramb.cd_ati_med IN (04)
then 'Terceiro Auxiliar'
when iramb.cd_ati_med IN (09)
then 'Instrumentador'     
when iramb.cd_ati_med IN (06)
then 'Anestesista' 
when iramb.cd_ati_med IN (14)
then 'Intensivista' 
end Grau_Participacao                   
from 
dbamv.reg_amb ramb
inner join dbamv.itreg_amb iramb on iramb.cd_reg_amb = ramb.cd_reg_amb
inner join dbamv.atendime atend1 on atend1.cd_atendimento = iramb.Cd_Atendimento
inner join dbamv.convenio conv1 on conv1.cd_convenio = iramb.cd_convenio
left join dbamv.tuss ts1 on ts1.cd_pro_fat = iramb.cd_pro_fat and ts1.cd_multi_empresa = ramb.cd_multi_empresa
                                                              and ts1.Cd_Convenio = iramb.Cd_Convenio
inner join dbamv.gru_fat gf1 on gf1.cd_gru_fat = iramb.cd_gru_fat
inner join dbamv.pro_Fat pf1 on pf1.cd_pro_fat = iramb.cd_pro_fat   
inner join dbamv.tip_tuss tts1 on tts1.cd_tip_tuss = ts1.cd_tip_tuss
left join dbamv.prestador prest1 on prest1.cd_prestador = iramb.cd_prestador
where conv1.tp_convenio = 'C'
---and iramb.Cd_Atendimento = 2588455   
and iramb.sn_pertence_pacote = 'N'                                                  
