select
rm.cd_remessa id_remessa,
rm.dt_abertura data_emissao,
case when rm.sn_Fechada = 'N' then 'false' else 'True' end Fechada,
rm.dt_abertura data_Cadastro,
''responsavel_Cadastro,
''data_atualizacao,
''resposavel_atualizacao   
from 
dbamv.remessa_Fatura rm
--where rm.cd_remessa = 182520

